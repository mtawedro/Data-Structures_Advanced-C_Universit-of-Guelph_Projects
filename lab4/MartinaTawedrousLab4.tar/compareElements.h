#ifndef COMPAREELEMENTS_H_INCLUDED
#define COMPAREELEMENTS_H_INCLUDED


/* 
 *  Structure
 */

struct element {
   int id_number;
   char last_name[10];
   float salary;
};



#endif
